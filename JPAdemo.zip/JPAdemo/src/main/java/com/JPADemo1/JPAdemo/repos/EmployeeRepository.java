package com.JPADemo1.JPAdemo.repos;

import com.JPADemo1.JPAdemo.entities.Employee;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface EmployeeRepository extends CrudRepository<Employee, Integer> {

    List<Employee> findByName(String name);

    List<Employee> findByNameLike(String namelike);

    List<Employee> findByAgeBetween(int min, int max);

    List<Employee> findAll(Pageable pageable);
}
