package com.JPADemo1.JPAdemo;

import com.JPADemo1.JPAdemo.entities.Employee;
import com.JPADemo1.JPAdemo.repos.EmployeeRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import java.util.List;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@SpringBootTest
class JPAdemoApplicationTests {

	@Autowired
	EmployeeRepository employeeRepository;

	@Test
	void contextLoads() {
	}

	@Test
	public void testCreate() {
		Employee employee1 = new Employee();
		employee1.setId(3);
		employee1.setName("Nirbhay");
		employee1.setAge(25);
		employee1.setLocation("Punjab");

		Employee employee2 = new Employee();
		employee2.setId(2);
		employee2.setName("Sagar");
		employee2.setAge(30);
		employee2.setLocation("New Delhi");

		Employee employee3 = new Employee();
		employee3.setId(1);
		employee3.setName("Abhilesh");
		employee3.setAge(25);
		employee3.setLocation("New Delhi");


		employeeRepository.save(employee1);
		employeeRepository.save(employee2);
		employeeRepository.save(employee3);
	}

   @Test
    public void testRead() {
        Employee employee = employeeRepository.findById(1).get();
        assertNotNull(employee);
        assertEquals("Abhilesh", employee.getName());

    }

    @Test
    public void testUpdate() {
        Employee employee = employeeRepository.findById(1).get();
        employee.setAge(24);
        employeeRepository.save(employee);

    }

    @Test
    public void testDelete() {
       employeeRepository.deleteById(1);
    }

	@Test
	public void testCount() {
		System.out.println("Total Records in Employee Table = " +employeeRepository.count());
	}

	@Test
	public void testfindByName() {
		List<Employee> employeeList = employeeRepository.findByName("Abhilesh");
		employeeList.forEach(p-> System.out.println("ID - " +p.getId()+ ", Location - " +p.getLocation()));
	}

	@Test
	public void testfindByNameLike() {
		List<Employee> employeeList = employeeRepository.findByNameLike("A%");
		employeeList.forEach(p-> System.out.println("ID - " +p.getId()+ ", Name - " +p.getName()));
	}

	@Test
	public void testfindByAgeBetween() {
		List<Employee> employeeList = employeeRepository.findByAgeBetween(28,32);
		employeeList.forEach(p-> System.out.println("ID - " +p.getId()+ ", Name - " +p.getName()));

	}


	@Test
	public void testPagingAndSortingEmployee(){
		Pageable pageable = PageRequest.of(0,4, Sort.Direction.ASC,"age");
		employeeRepository.findAll(pageable).forEach(p-> System.out.println(p.getName()));
	}

}