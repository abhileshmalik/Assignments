package com.practice.Restful.RestfulDemo.Employee;

import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Component
public class EmployeeDaoService {

    private static List<Employee> employees = new ArrayList<>();
    private static int empCount = 4;

    static {
        employees.add(new Employee(1,"Abhilesh", 23));
        employees.add(new Employee(2,"Shubham", 22));
        employees.add(new Employee(3,"Sagar", 24));
        employees.add(new Employee(4,"Nirbhay", 21));
    }

    public List<Employee> findAll() {
        return employees;
    }


    public Employee save (Employee employee) {
        if (employee.getId()==null) {
            employee.setId(++empCount);
        }
        employees.add(employee);
        return employee;

    }

    public Employee findOne(int id) {
        for(Employee employee : employees) {
            if(employee.getId()==id) {
                return employee;
            }
        }
        return null;
    }

    public Employee deleteById(int id) {
        Iterator<Employee> iterator = employees.iterator();
        while (iterator.hasNext()) {
            Employee employee = iterator.next();
             if(employee.getId()==id) {
                 iterator.remove();
             }
        }
        return null;
    }

    /*public Employee updatebyId(int id) {
        Employee currentEmployee;
        currentEmployee.setAge(employee.getAge());
        currentEmployee.setName(employee.getName());

    }

     */

    public Employee updateById(Employee employe,int id) {
//
        Employee employee = findOne(id);
        if(employe!=null) {
            employee.setAge(employe.getAge());
            employee.setName(employe.getName());
            return employee;
        }
        else
           throw  new UserNotFoundException("hello");

    }

}
