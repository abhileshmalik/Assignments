package com.practice.Restful.RestfulDemo.Employee;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.web.ServerProperties;
//import org.springframework.hateoas.EntityModel;
//import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
//import org.springframework.hateoas.EntityModel;
//import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import javax.validation.Valid;
import java.net.URI;
import java.util.List;

@RestController
public class EmployeeService {

    @Autowired
    private EmployeeDaoService service;

    @GetMapping("/employees")
    public List<Employee> retrieveAllEmployees() {
        return service.findAll();
    }

   /* @GetMapping("/employees/{id}")
    public EntityModel <Employee> retrieveEmployee(@PathVariable int id) {
        Employee employee =  service.findOne(id);
        if(employee==null)
        {
            throw new UserNotFoundException("id : "+id);
        }

        EntityModel<Employee> model = new EntityModel<>(employee);
        WebMvcLinkBuilder linkTo = linkTo(methodOn(this.getClass()).retrieveAllEmployees());
        model.add(linkTo.withRel("all-Employees"));

        return model;
    }*/

    @PostMapping("/employees")
    public ResponseEntity<Object> createEmployee(@Valid @RequestBody Employee employee) {
        Employee savedEmployee = service.save(employee);

        URI location =  ServletUriComponentsBuilder.fromCurrentRequest()
                .path("/{id}").buildAndExpand(savedEmployee.getId())
                .toUri();

        return ResponseEntity.created(location).build();
    }

    @PutMapping(path = "/employees/update/{id}")
    public Employee updateEmployee(@RequestBody Employee employee,@PathVariable int id) {

        return service.updateById(employee,id);

    }

    @DeleteMapping("/employees/{id}")
    public void deleteEmployee(@PathVariable int id) {
        Employee employee = service.deleteById(id);

        if(employee==null)
        {
            throw new UserNotFoundException("id : "+id);
        }
    }
}
