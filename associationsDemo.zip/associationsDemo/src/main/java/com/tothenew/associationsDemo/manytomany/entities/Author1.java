package com.tothenew.associationsDemo.manytomany.entities;

import javax.persistence.*;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "authorm2m")
public class Author1 {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    private String name;
    private int age;
    @Embedded
    private Address1 address;

    @ElementCollection
    @CollectionTable(joinColumns=@JoinColumn(name="id"))
    @Column(name="subjects")
    private List<String> subjects;

    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(name = "authors_books",
    joinColumns = @JoinColumn(name = "author_id",referencedColumnName = "id"),
    inverseJoinColumns = @JoinColumn(name = "book_id",referencedColumnName = "id"))
    private Set<Book1> books;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public Address1 getAddress() {
        return address;
    }

    public void setAddress(Address1 address) {
        this.address = address;
    }

    public Set<Book1> getBooks() {
        return books;
    }

    public void setBooks(Set<Book1> books) {
        this.books = books;
    }

    public List<String> getSubjects() {
        return subjects;
    }

    public void setSubjects(List<String> subjects) {
        this.subjects = subjects;
    }
}
