package com.tothenew.associationsDemo.manytomany.repos;

import com.tothenew.associationsDemo.manytomany.entities.Author1;
import org.springframework.data.repository.CrudRepository;

public interface Author1Repository extends CrudRepository<Author1, Integer> {

}
