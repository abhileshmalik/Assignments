package com.tothenew.associationsDemo.onetomany.entities;

import javax.persistence.*;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "authoro2m")
public class Author2 {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    private String name;
    private int age;
    @Embedded
    private Address2 address;

    @ElementCollection
    @CollectionTable(joinColumns=@JoinColumn(name="id"))
    @Column(name="subjects")
    private List<String> subjects;

    @OneToMany(mappedBy = "author", cascade = CascadeType.ALL)
    private Set<Book2> books;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public Address2 getAddress() {
        return address;
    }

    public void setAddress(Address2 address) {
        this.address = address;
    }

    public List<String> getSubjects() {
        return subjects;
    }

    public void setSubjects(List<String> subjects) {
        this.subjects = subjects;
    }

    public Set<Book2> getBooks() {
        return books;
    }

    public void setBooks(Set<Book2> books) {
        this.books = books;
    }

    public void addBooks(Book2 book) {
        if (book !=null) {
            if (books==null) {
                books = new HashSet<>();
            }
            book.setAuthor(this);
            books.add(book);
        }
    }
}
