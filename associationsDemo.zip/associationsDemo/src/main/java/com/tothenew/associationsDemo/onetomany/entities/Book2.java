package com.tothenew.associationsDemo.onetomany.entities;

import javax.persistence.*;

@Entity
@Table(name = "booko2m")
public class Book2 {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    private String book_name;

    @ManyToOne                              // Right now its bidirectional, we can comment this @ManytoOne in case of Unidirectional
    @JoinColumn(name = "author_id")
    private Author2 author;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBook_name() {
        return book_name;
    }

    public void setBook_name(String book_name) {
        this.book_name = book_name;
    }

    public Author2 getAuthor() {
        return author;
    }

    public void setAuthor(Author2 author) {
        this.author = author;
    }
}
