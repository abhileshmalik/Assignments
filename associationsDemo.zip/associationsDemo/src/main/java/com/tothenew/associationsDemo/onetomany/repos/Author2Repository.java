package com.tothenew.associationsDemo.onetomany.repos;

import com.tothenew.associationsDemo.onetomany.entities.Author2;
import org.springframework.data.repository.CrudRepository;

public interface Author2Repository extends CrudRepository<Author2, Integer> {

}
