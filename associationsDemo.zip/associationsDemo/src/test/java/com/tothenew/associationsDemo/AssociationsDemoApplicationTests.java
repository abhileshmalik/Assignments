package com.tothenew.associationsDemo;

import com.tothenew.associationsDemo.manytomany.entities.Address1;
import com.tothenew.associationsDemo.manytomany.entities.Author1;
import com.tothenew.associationsDemo.manytomany.entities.Book1;
import com.tothenew.associationsDemo.manytomany.repos.Author1Repository;
import com.tothenew.associationsDemo.onetomany.entities.Address2;
import com.tothenew.associationsDemo.onetomany.entities.Author2;
import com.tothenew.associationsDemo.onetomany.entities.Book2;
import com.tothenew.associationsDemo.onetomany.repos.Author2Repository;
import com.tothenew.associationsDemo.onetoone.entities.Address;
import com.tothenew.associationsDemo.onetoone.entities.Author;
import com.tothenew.associationsDemo.onetoone.entities.Book;
import com.tothenew.associationsDemo.onetoone.repos.AuthorRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

@SpringBootTest
class AssociationsDemoApplicationTests {

	@Autowired
	AuthorRepository authorRepositoryo2o;

	@Autowired
	Author1Repository authorRepositorym2m;

	@Autowired
    Author2Repository authorRepositoryo2m;

	@Test
	void contextLoads() {
	}

	@Test
	public void testOneToOneCreateAuthor() {		//Testing O2O mapping
		Author author1 = new Author();
		author1.setName("Abhilesh Malik");
		author1.setAge(23);

		List<String> subjects = new ArrayList<>();
		subjects.add("Subject 1");
		subjects.add("Subject 2");
		subjects.add("Subject 3");

		Book book1 = new Book();
		book1.setBook_name("Spiti Life");

		Address address1 = new Address();
		address1.setStreet_number("J-2/7");
		address1.setLocation("Tagore Garden");
		address1.setState("Delhi");

		author1.setSubjects(subjects);
		author1.setAddress(address1);
		author1.setBook(book1);

		authorRepositoryo2o.save(author1);
	}

	@Test
	public void testm2mcreateAuthor() {			//Testing M2M mapping

		Author1 author1=new Author1();
		author1.setName("Shubham Jain");
		author1.setAge(22);

		Author1 author2=new Author1();
		author2.setName("Abhilesh Malik");
		author2.setAge(23);

		HashSet<Book1> bookHashSet1 = new HashSet<Book1>();
		HashSet<Book1> bookHashSet2 = new HashSet<Book1>();
		HashSet<Author1> authorSet = new HashSet<>();

		Book1 book1 = new Book1();
		book1.setBook_name("Being Entrepreneur");
		authorSet.add(author1);
		authorSet.add(author2);
		book1.setAuthor(authorSet);

		Book1 book2 = new Book1();
		book2.setBook_name("Learn Java");
		book2.setAuthor(authorSet);

		bookHashSet1.add(book1);
		bookHashSet1.add(book2);

		bookHashSet2.add(book1);

		author1.setBooks(bookHashSet1);
		author2.setBooks(bookHashSet2);

		List<String> subjects1 = new ArrayList<>();
		subjects1.add("Physics");
		subjects1.add("Science");
		subjects1.add("Journalism");

		List<String> subjects2 = new ArrayList<>();
		subjects2.add("Psychology");
		subjects2.add("Science");
		subjects2.add("Social Service");

		Address1 address1 = new Address1();
		address1.setStreet_number("C-65");
		address1.setLocation("Karol Bagh");
		address1.setState("Delhi");

		Address1 address2 = new Address1();
		address2.setStreet_number("C-54");
		address2.setLocation("Tagore Garden");
		address2.setState("Delhi");

		author1.setSubjects(subjects1);
		author1.setAddress(address1);

		author2.setSubjects(subjects2);
		author2.setAddress(address2);

		authorRepositorym2m.save(author1);
		authorRepositorym2m.save(author2);
	}


    @Test
    public void testCreateAuthoro2m() {			//Testing O2M mapping
	    Author2 author1 = new Author2();
	    author1.setName("Nirbhay Khurana");
	    author1.setAge(23);

        List<String> subjects1 = new ArrayList<>();
        subjects1.add("HTML");
        subjects1.add("CSS");
        subjects1.add("Java");

        Address2 address = new Address2();
        address.setStreet_number("D-115");
        address.setLocation("Dwarka sector-16");
        address.setState("Delhi");

        Book2 b1 = new Book2();
        b1.setBook_name("HTML Basics");
        b1.setAuthor(author1);

        Book2 b2 = new Book2();
        b2.setBook_name("Implementing CSS");
        b2.setAuthor(author1);

        author1.addBooks(b1);
        author1.addBooks(b2);

        author1.setSubjects(subjects1);
        author1.setAddress(address);

        authorRepositoryo2m.save(author1);
    }


}
