package com.JPADemo2.demo2.entities;

import javax.persistence.Embeddable;

@Embeddable
public class TotalSalary {

    private double basicsalary;
    private double bonussalary;
    private double specialallowance;

    public double getBasicsalary() {
        return basicsalary;
    }

    public void setBasicsalary(double basicsalary) {
        this.basicsalary = basicsalary;
    }

    public double getBonussalary() {
        return bonussalary;
    }

    public void setBonussalary(double bonussalary) {
        this.bonussalary = bonussalary;
    }

    public double getSpecialallowance() {
        return specialallowance;
    }

    public void setSpecialallowance(double specialallowance) {
        this.specialallowance = specialallowance;
    }
}
