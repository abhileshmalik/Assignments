package com.JPADemo2.demo2.repos;

import com.JPADemo2.demo2.entities.Employee1;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface Employee1Repository extends CrudRepository<Employee1, Integer> {

    //MySQL Query
    //select emp_first_name,emp_last_name from employee_table where emp_salary>(select avg(emp_salary)
    // from employee_table order by emp_age, emp_salary desc);
    @Query("select firstName,lastName from Employee1 where salary>(select avg(salary)from Employee1 order by age, salary desc)")
    List<Object[]> findAllEmployeesPartialData();

    //update employee_table
    //set emp_salary=800
    //where emp_salary<(select * from(select avg(emp_salary) from employee_table) employee_table);
    @Modifying
    @Transactional
    @Query("update Employee1 set salary=1000.50 where salary<(select * (select avg(salary) from Employee1) Employee1")
     void updateSalaryByGivenAmount();


    @Query(value = "select emp_first_name, emp_last_name, emp_age from employee_table where emp_last_name Like '%Singh'", nativeQuery = true) // when we use nativeQuery as true we can directly pass SQL statements here to execute
    List<Object[]> findEmployeeNameEndingWithSinghNQ();


    @Modifying
    @Query(value = "delete from employee_table where emp_age>:delage", nativeQuery = true)
    void deleteEmpAboveGivenAge(@Param("delage") int delage);

}
