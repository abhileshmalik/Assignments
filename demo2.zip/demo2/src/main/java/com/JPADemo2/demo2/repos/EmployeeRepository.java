package com.JPADemo2.demo2.repos;

import com.JPADemo2.demo2.entities.Employee;
import org.springframework.data.repository.CrudRepository;

public interface EmployeeRepository extends CrudRepository<Employee, Integer> {

}
