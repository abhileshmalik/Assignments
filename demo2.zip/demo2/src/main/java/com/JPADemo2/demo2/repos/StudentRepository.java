package com.JPADemo2.demo2.repos;

import com.JPADemo2.demo2.entities.Student;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface StudentRepository extends CrudRepository<Student, Long> {

    @Query("from Student")              // Right now its fetching from Student<Entity>
    List<Student> findAllStudents(Pageable pageable);

    @Query("select st.firstName, st.lastName from Student st")
    List<Object[]> findAllStudentsPartialData();

    @Query("from Student where firstName=:firstName")
    List<Student> findAllStudentByFirstName(@Param("firstName") String firstName );

    @Query("from Student where score>:min and score<:max")
    List<Student> findStudentsForGivenScores(@Param("min") int min, @Param("max") int max);

    @Query(value = "select * from student",nativeQuery = true) // when we use nativeQuery as true we can directly pass SQL statements here to execute
    List<Student> findAllStudentNQ();

}
