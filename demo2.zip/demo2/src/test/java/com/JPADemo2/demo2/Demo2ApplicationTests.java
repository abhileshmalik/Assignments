package com.JPADemo2.demo2;

import com.JPADemo2.demo2.entities.*;
import com.JPADemo2.demo2.repos.Employee1Repository;
import com.JPADemo2.demo2.repos.EmployeeRepository;
import com.JPADemo2.demo2.repos.PaymentRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@SpringBootTest
class Demo2ApplicationTests {

	@Autowired
	PaymentRepository paymentRepository;

	@Autowired
	Employee1Repository employee1Repository;

	@Autowired
	EmployeeRepository employeeRepository;


	@Test
	public void testPaymentCreate() {
		Check check1 = new Check();
		check1.setId(1);
		check1.setAmount(1000.00);
		check1.setChecknumber("01156754893");

		CreditCard creditCard = new CreditCard();
		creditCard.setId(2);
		creditCard.setAmount(1600.90);
		creditCard.setCardnumber("535498768973");

		paymentRepository.save(check1);
		paymentRepository.save(creditCard);
	}

	@Test
	public void testEmployeeCreate() {
		Employee employee1 = new Employee();
		employee1.setId(1);
		employee1.setFirstname("Abhilesh");
		employee1.setLastname("Malik");
		employee1.setAge(23);
		employee1.setTaxamount(100d);

		TotalSalary totalSalary1 = new TotalSalary();
		totalSalary1.setBasicsalary(2500d);
		totalSalary1.setBonussalary(100d);
		totalSalary1.setSpecialallowance(500d);

		employee1.setTotalSalary(totalSalary1);
		employeeRepository.save(employee1);
	}

	@Test
	public void testEmployeeMainCreate() {
		Employee1 employee1 = new Employee1();
		employee1.setId(1);
		employee1.setFirstName("Abhilesh");
		employee1.setLastName("Malik");
		employee1.setSalary(5000d);
		employee1.setAge(23);

		Employee1 employee2 = new Employee1();
		employee2.setId(2);
		employee2.setFirstName("Nirbhay");
		employee2.setLastName("Khurana");
		employee2.setSalary(500d);
		employee2.setAge(24);

		Employee1 employee3 = new Employee1();
		employee3.setId(3);
		employee3.setFirstName("Shubham");
		employee3.setLastName("Jain");
		employee3.setSalary(2000d);
		employee3.setAge(22);

		Employee1 employee4 = new Employee1();
		employee4.setId(4);
		employee4.setFirstName("Karamjeet");
		employee4.setLastName("Singh");
		employee4.setSalary(1000d);
		employee4.setAge(22);

		Employee1 employee5 = new Employee1();
		employee5.setId(5);
		employee5.setFirstName("Sagar");
		employee5.setLastName("Gandhi");
		employee5.setSalary(3000d);
		employee5.setAge(25);

		Employee1 employee6 = new Employee1();
		employee6.setId(6);
		employee6.setFirstName("Chetan");
		employee6.setLastName("Virk");
		employee6.setSalary(5500d);
		employee6.setAge(26);

		Employee1 employee7 = new Employee1();
		employee7.setId(7);
		employee7.setFirstName("Sid");
		employee7.setLastName("Gupta");
		employee7.setSalary(4800d);
		employee7.setAge(26);

		employee1Repository.save(employee1);
		employee1Repository.save(employee2);
		employee1Repository.save(employee3);
		employee1Repository.save(employee4);
		employee1Repository.save(employee5);
		employee1Repository.save(employee6);
		employee1Repository.save(employee7);
	}


	@Test
	public void testfindAllEmployeesPartialData() {
		List<Object[]> partialData = employee1Repository.findAllEmployeesPartialData();
		for (Object[] objects :partialData) {
			System.out.println(objects[0]);
			System.out.println(objects[1]);
		}
	}

	@Test
	@Transactional
	@Rollback(false)
	public void testupdateSalaryByGivenAmount() {
		employee1Repository.updateSalaryByGivenAmount();
	}

	@Test
	public void testfindEmployeeHavingNameEndingWithSinghNQ() {
		List<Object[]> employeeData = employee1Repository.findEmployeeNameEndingWithSinghNQ();
		for (Object[] objects : employeeData) {
			System.out.println(objects[0]);
			System.out.println(objects[1]);
			System.out.println(objects[2]);
		}
	}

	@Test
	@Transactional
	@Rollback(false)
	public void testdeleteEmpAboveGivenAge() {
		employee1Repository.deleteEmpAboveGivenAge(30);
	}
}
