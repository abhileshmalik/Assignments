package com.rest2.restful.part2.DynamicFiltering;

import com.fasterxml.jackson.databind.ser.FilterProvider;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;

@RestController
public class User2Controller {

    //id, name
    @GetMapping("/dynamic-filtering/users")
    public MappingJacksonValue retrieveUsers2(){
        User2 user = new User2(101,"Abhilesh","1234");

        SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("id","name");

        FilterProvider filterProvider=new SimpleFilterProvider().addFilter("filter",filter);

        MappingJacksonValue mapping=new MappingJacksonValue(user);

        mapping.setFilters(filterProvider);

        return mapping;
    }

    //name
    @GetMapping("/dynamic-filtering-list/users")
    public MappingJacksonValue retrieveUserList(){
        List<User2> list = Arrays.asList(new User2(201,"sid","111"),
                new User2(202,"Shubham","222"));

        SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("name");

        FilterProvider filterProvider=new SimpleFilterProvider().addFilter("filter",filter);

        MappingJacksonValue mapping=new MappingJacksonValue(list);

        mapping.setFilters(filterProvider);

        return mapping;


    }
}
