package com.rest2.restful.part2.StaticFiltering;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {

    @GetMapping("/static-filtering/users")
    public User retrieveUsers(){
        return new User(101,"Abhilesh","1234");
    }

}
