package com.rest2.restful.part2;

import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Component
public class empDaoService {

    private static int empCount=3;
    private static List<employee> emp=new ArrayList<>();

    static {
        emp.add(new employee(1,23,"Abhilesh"));
        emp.add(new employee(2,22,"Shubham"));
        emp.add(new employee(3,24,"Sagar"));
    }

    public List<employee> findAll(){
        return emp;
    }

    public employee save(employee emp1){
        if (emp1.getId()==null){
            emp1.setId(++empCount);
        }
        emp.add(emp1);
        return emp1;
    }

    public employee findOne(int id){
        for(employee emp1:emp){
            if (emp1.getId()==id){
                return emp1;
            }
        }
        return null;
    }

    public employee deleteById(int id){
        Iterator<employee> iterator=emp.iterator();
        while (iterator.hasNext()){
            employee emp1=iterator.next();
            if (emp1.getId()==id){
                iterator.remove();
                return emp1;
            }
        }
        return null;
    }
}
