package com.rest2.restful.part2.versioning;

public class User1 {
    private String name;

    public User1(){}

    public User1(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
