package com.rest2.restful.part2.versioning;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserVersioningController {

    //URI versioning
    @GetMapping("u1/user")
    public User1 user1(){
        return new User1("Abhilesh Malik");
    }

    @GetMapping("u2/user")
    public User2 user2(){
        return new User2(new Name("Abhilesh", "Malik"));
    }

    //Request Parameter versioning
    @GetMapping(value = "/user/param", params = "version=1")
    public User1 param1(){
        return new User1("Abhilesh Malik");
    }

    @GetMapping(value = "/user/param", params = "version=2")
    public User2 param2(){
        return new User2(new Name("Abhilesh", "Malik"));
    }

    //Custom Header Versioning
    @GetMapping(value = "/user/header", headers = "X-API-VERSION=1")
    public User1 header1(){
        return new User1("Abhilesh Malik");
    }

    @GetMapping(value = "/user/header", headers = "X-API-VERSION=2")
    public User2 header2(){
        return new User2(new Name("Abhilesh", "Malik"));
    }

    //MimeType Versioning
    @GetMapping(value = "/user/mimetype", produces = "application/vnd.company.app-v1+json")
    public User1 mimetype1(){
        return new User1("Abhilesh Malik");
    }

    @GetMapping(value = "/user/mimetype", produces = "application/vnd.company.app-v2+json")
    public User2 mimetype2(){
        return new User2(new Name("Abhilesh", "Malik"));
    }


}
