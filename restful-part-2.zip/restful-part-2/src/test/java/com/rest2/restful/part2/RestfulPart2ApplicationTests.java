package com.rest2.restful.part2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfulPart2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
