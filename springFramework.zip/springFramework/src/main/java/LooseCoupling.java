/*
public class LooseCoupling {

    public static void main(String[] args) {

        new Manager(new LazyWorker()).manageWork();
        new Manager(new ExcellantWorker()).manageWork();
    }

}

class Manager {

    private Worker worker;

    public Manager(Worker worker) {

        this.worker = worker;       //Loose Coupling

    }

    public void manageWork() {

        worker.doWork();

    }
}


//Instead of Managing each worker Individually we create a Worker Interface and all workers implement this Interface
interface Worker {
    public void doWork();
}


class LazyWorker implements Worker {

    public void doWork() {
        System.out.println("Lazy worker is Working");
    }

}

class ExcellantWorker implements Worker {

    public void doWork() {
        System.out.println("Excellant worker is Working");
    }
}


 */