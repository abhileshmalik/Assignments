public class TightCoupling {

    public static void main(String[] args) {

        new Manager(new LazyWorker(), new ExcellantWorker()).manageWork();
    }
}

class Manager {


    private LazyWorker lw;
    private ExcellantWorker ew;

    public Manager(LazyWorker lw, ExcellantWorker ew) {

        this.lw = lw;
        this.ew = ew;
    }

    public void manageWork() {
        lw.doWork();
        ew.doWork();
    }
}


class LazyWorker {

    public void doWork() {
        System.out.println("Lazy worker is Working");
    }

}

class ExcellantWorker {

    public void doWork() {
        System.out.println("Excellant worker is Working");
    }
}