package com.tothenew.bootcamp.springFramework;

import org.springframework.stereotype.Component;

@Component
public class ExcellantWorker implements Worker {

    public void doWork() {
        System.out.println("Excellent worker is Working");
    }
}