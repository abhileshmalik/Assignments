package com.tothenew.bootcamp.springFramework;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component    //We cannot make 2 Component at once as it creates conflict for Spring to pick the right bean so use Primary
@Primary
public class LazyWorker implements Worker {
    @Override
    public void doWork() {
        System.out.println("Lazy worker is Working");
    }
}
