package com.tothenew.bootcamp.springFramework;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@Component
public class Manager {

    private Worker worker;

    /*
    @Autowired
    @Qualifier("lazyWorker")
    private Worker worker;

    @Bean("lazyWorker")
    LazyWorker lazyWorker() {
        return new LazyWorker();
    }
    */

    /*
    @Autowired
    @Qualifier("excellantWorker")
    private Worker excellantWorker;

    @Bean("excellantWorker")
    ExcellantWorker excellantWorker() {
        return new ExcellantWorker();
    }

     */

//////////////// Constructor Injection Demo - /////////////////////

    @Autowired
    public void setWorker (Worker worker) {                //Method 1 (Using Setters)
        this.worker = worker;
    }



    /*
    @Autowired
    public Manager(Worker worker) {                         //Method 2 (Using Constructors)
        this.worker = worker;
    }

     */



    public void manageWork() {

        worker.doWork();
        //excellantWorker.doWork();
    }
}
