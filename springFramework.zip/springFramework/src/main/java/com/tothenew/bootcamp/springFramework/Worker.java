package com.tothenew.bootcamp.springFramework;

public interface Worker {
    public void doWork();
}
