package com.im;

import healthycoderapp.BMICalculator;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class FirstTest {

    private First first=new First();

    @Test
    void should_replaceSubString_When_String_is_NotEmpty () {

        //given
        String mainString="hello world";
        String subString="world";
        String replacementString="earth";
        String expected = "hello earth";

        //when
        String actual = first.replaceSubString(mainString,subString,replacementString);

        //then
        assertEquals(expected, actual, "String Match");

    }

    @Test
    public void should_ThrowNullPointerException_When_StringIsEmpty() {

        //given
        String mainString="abc";
        String subString=null;
        String replacementString="abc";
        String expected = "abc";

        //when
        String actual = first.replaceSubString(mainString,subString,replacementString);

        //then
        assertEquals(expected, actual);
    }



    @Test
    void shouldReturnOriginalString_When_SubstringIsNotFound() {
        //given
        String mainString = "abc xyz";
        String findstring = "heg";
        String replacedString = "ttn";
        String expectedString = "abc xyz";

        //when
        String calculateString = first.replaceSubString(mainString, findstring, replacedString);

        //then
        assertEquals(expectedString, calculateString);

    }

    @Test
    void shouldReturnOddElementOnly_When_OddElementExist_AfterFilterEvenElement() {
        //given
        List<Integer> list = new ArrayList<>();
        for (int i = 1; i < 6; i++) {
            list.add(i);
        }
        List<Integer> expectedlist = new ArrayList<>();
        expectedlist.add(1);
        expectedlist.add(3);
        expectedlist.add(5);

        //when
        List calculatelist = first.filterEvenElements(list);

        //then
        assertEquals(expectedlist, calculatelist);

    }

    @Test
    void shouldThrowMessageInvalidInput_When_ListIsNotExist() {
        //given
        List<BigDecimal> list = null;
        //List<BigDecimal> list=new ArrayList<>();

        //when

        /*
        try {
            first.calculateAverage(list);
        }

        catch (RuntimeException r) {
            System.out.println(r);

        }

         */

        Executable executable = () -> first.calculateAverage(list);

        // then
        assertThrows(RuntimeException.class, executable);

    }

    @Test
    void shouldThrowMessageInvalidInput_When_ListIsEmpty() {
        //given
        List<BigDecimal> list = new ArrayList<>();

        //when
        Executable executable = () -> first.calculateAverage(list);

        // then
        assertThrows(RuntimeException.class, executable);
    }

    @Test
    void shouldReturnAveragevalue_When_ListContainsElement() {

        //given
        List<BigDecimal> list = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            list.add(new BigDecimal(1212121));
            list.add(new BigDecimal(1212121));
            list.add(new BigDecimal(1212121));
            list.add(new BigDecimal(1212121));
        }
        BigDecimal expectedaverage = new BigDecimal(1212121);

        //when
        BigDecimal calculateaverage = first.calculateAverage(list);

        //then
        assertEquals(expectedaverage, calculateaverage);
    }

    @Test
    void shouldReturnFalse_When_StringIspalindrome() {
        //given
        String originalinput = "abhilesh";
        String lower = originalinput.toLowerCase();


        //when
        boolean palindromecheck = first.isPallindrome(lower);

        //then
        assertFalse(palindromecheck);

    }

    @Test
    void shouldReturnTrue_When_StringIspalindrome() {

        //given
        String originalinput = "Naman";
        String lower = originalinput.toLowerCase();

        //when
        boolean palindromecheck = first.isPallindrome(lower);

        //then
        assertTrue(palindromecheck);

    }


}