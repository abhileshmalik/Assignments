package healthycoderapp;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class BMICalculatorTest {

    @BeforeAll
    static void beforeAll() {
        System.out.println("Before All Unit Tests");
    }

    @AfterAll
    static void afterAll() {
        System.out.println("After All Unit Tests");
    }

    @ParameterizedTest(name = "Weight = {0}, Height = {1}")
    @CsvFileSource(resources = "/CoderData.csv", numLinesToSkip=1)
    void should_ReturnTrue_when_DietRecommended(Double coderWeight, Double coderHeight) {

        //given
        double weight = coderWeight;
        double height = coderHeight;

        //when
        boolean recommended = BMICalculator.isDietRecommended(weight, height);

        // then
        assertTrue(recommended);

    }

    @Test
    void should_ReturnFalse_when_DietNotRecommended() {

        //given
        double weight = 50.0;
        double height = 1.8;

        //when
        boolean recommended = BMICalculator.isDietRecommended(weight, height);

        // then
        assertFalse(recommended);

    }

    @Test
    void should_ThrowsArithmeticException_When_HeightZero() {

        //given
        double weight = 50.0;
        double height = 0.0;

        //when
        Executable executable = () -> BMICalculator.isDietRecommended(weight, height);


        // then
        assertThrows(ArithmeticException.class, executable);

    }

    @Test
    void should_ReturnCoderWithWorstBMI_When_CoderListisNotEmpty() {

        //given
        List<Coder> coders = new ArrayList<>();
        coders.add(new Coder(1.82, 98.0));
        coders.add(new Coder(1.80, 61.10));
        coders.add(new Coder(1.82, 51.80));
        coders.add(new Coder(1.86, 65.50));

        //when
        Coder coderWorstBMI = BMICalculator.findCoderWithWorstBMI(coders);

        //then

        assertAll(
                () -> assertEquals(1.82, coderWorstBMI.getHeight()),
                () -> assertEquals(98.0, coderWorstBMI.getWeight())
        );

    }

    @Test
    void should_ReturnNullWorstBMICoder_When_CoderListEmpty() {

        //given
        List<Coder> coders = new ArrayList<>();

        //when
        Coder coderWorstBMI = BMICalculator.findCoderWithWorstBMI(coders);

        //then
        assertNull(coderWorstBMI);
    }

    @Test
    void should_ReturnCorrectBMIScoreArray_When_CoderListNotEmpty() {

        //given
        List<Coder> coders = new ArrayList<>();
        coders.add(new Coder(1.82, 98.0));
        coders.add(new Coder(1.80, 60.0));
        coders.add(new Coder(1.82, 64.70));
        double[] expected = {29.59, 18.52, 19.53};

        //when
        double[] bmiScores = BMICalculator.getBMIScores(coders);

        //then
        assertArrayEquals(expected, bmiScores);
    }

}